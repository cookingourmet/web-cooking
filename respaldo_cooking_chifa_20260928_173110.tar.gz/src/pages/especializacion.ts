import { deliverLead, LeadDeliveryError } from "../utils/lead-delivery";
import { pageLocation, readAttribution, trackEvent } from "../utils/analytics";
import { renderHeader, initHeader } from "../components/layout/header/header";
import { renderFooter } from "../components/layout/footer/footer";
import { initSpecializationSwirlBackground } from "../components/effects/swirlBackground";

const WHATSAPP_NUMBER = "51981377382";
const LEAD_ENDPOINT = "/api/specialization-lead";

const SPECIALIZATION = {
  "name": "Especialización en Cocina Chifa",
  "instructor": "Docentes altamente capacitados",
  "location": "Modalidad presencial",
  "city": "Huancayo, Junín",
  "chefImage": "/images/especializacion/chef.png",
  "chefMobileImage": "/images/especializacion/chef-1.png",
  "startDate": "5 de octubre",
  "duration": "10 sesiones de 3 horas",
  "schedule": "del 5 al 16 de octubre · 2:00 p.m. a 5:00 p.m.",
  "investment": "S/ 1,600.00",
  "certificate": "Certificado al culminar · costo adicional aproximado S/ 50.00",
  "topics": [
    "Arroces orientales",
    "Pollo oriental I",
    "Pollo oriental II",
    "Wantanes y especialidades",
    "Sopas orientales",
    "Técnicas de relleno y glaseado",
    "Cerdo oriental",
    "Dim Sum",
    "Especialidades y tallarines",
    "Cocina Taypa"
  ],
  "topicDescriptions": [
    "Arroz chaufa y aeropuerto oriental de fusión.",
    "Pollo crocante Chi Jau Kay con glaseado oriental y pollo Tipakay con glaseado agridulce.",
    "Pollo Limón Kay, cítricos y perfume de jengibre; chaufa nipón.",
    "Kam Lu Wantán y cerdo Cruyok con piña caramelizada y especias orientales.",
    "Consomé oriental de wantanes y consomé de tradición cantonesa Fuchifu.",
    "Alitas rellenas en salsa limón y enrollado de pollo.",
    "Cerdo glaseado con durazno caramelizado y salsa oriental; cerdo al wok con verduras y sésamo.",
    "Siu Mai y Min Pao.",
    "Piernitas Funkin Chonlon y tallarín saltado.",
    "Tallarín Taypa y Taypa plancha."
  ]
};

type SpecializationLeadPayload = {
  program: string;
  source: string;
  fullName: string;
  phone: string;
  email: string;
  dni: string;
  message: string;
  topics: string[];
  instructor: string;
  pageUrl: string;
  createdAt: string;
};

function buildWhatsAppUrl() {
  const message = [
    "Hola, vengo de la página web de Cooking Gourmet.",
    "Quiero información sobre la Especialización en Cocina Chifa.",
    "Deseo inscribirme al curso presencial que inicia el 5 de octubre.",
    "Quiero confirmar las 10 sesiones, el horario de 2:00 p.m. a 5:00 p.m., la inversión de S/ 1,600.00 y el certificado.",
  ].join("\n");

  return `https://wa.me/${WHATSAPP_NUMBER}?text=${encodeURIComponent(message)}`;
}

function isValidEmail(value: string) {
  if (!value) return true;
  return /^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(value);
}

async function sendSpecializationLeadToSales(
  payload: SpecializationLeadPayload
) {
  if (!payload.fullName || !payload.phone) {
    throw new Error("Completa tu nombre y celular.");
  }

  if (!isValidEmail(payload.email)) {
    throw new Error("Ingresa un correo válido.");
  }

  await deliverLead(LEAD_ENDPOINT, {
    submissionId: crypto.randomUUID(),
    ...payload,
    ...readAttribution(),
  });
}
function renderTopicCards() {
  return SPECIALIZATION.topics
    .map(
      (topic, index) => `
        <article class="specialization-topic-card reveal-up">
          <span class="specialization-topic-card__number">
            ${String(index + 1).padStart(2, "0")}
          </span>
          <h3>${topic}</h3>
          <p>${SPECIALIZATION.topicDescriptions[index]}</p>
        </article>
      `
    )
    .join("");
}

function renderSpecializationHero() {
  return `
    <section class="specialization-hero">
      <div class="specialization-hero__pattern" aria-hidden="true"></div>

      <canvas
        class="specialization-swirl-canvas"
        id="specializationSwirlCanvas"
        aria-hidden="true"
      ></canvas>

      <div class="container specialization-hero__container">
        <div class="specialization-hero__chef">
          <picture>
            <source
              media="(max-width: 820px)"
              srcset="${SPECIALIZATION.chefMobileImage}"
            />

            <img
              src="${SPECIALIZATION.chefImage}"
              alt="Especialización presencial en Cocina Chifa de Cooking Gourmet"
              loading="eager"
              decoding="async"
            />
          </picture>
        </div>

        <div class="specialization-hero__content">

          <h1 class="specialization-hero__title">
            Cocina Chifa
            <span>Sabor y técnica oriental.</span>
          </h1>

          <span class="specialization-eyebrow specialization-eyebrow--below">
            Especialización · 100% presencial
          </span>

          <div class="specialization-hero__topics" aria-label="Temas de la especialización">
            ${["Wok, salteados y arroces", "Pollo, cerdo y glaseados", "Wantanes, sopas y Dim Sum", "Tallarines y cocina Taypa", "10 sesiones · Insumos incluidos", "Inicio 5 de octubre · S/ 1,600"]
              .map(
                (topic) => `
                  <span>
                    <strong>●</strong>
                    ${topic}
                  </span>
                `
              )
              .join("")}
          </div>

          <div class="specialization-hero__actions">
            <button
                class="specialization-btn specialization-btn--primary"
                type="button"
                data-specialization-primary-action
            >
                Inscribirme ahora
            </button>
            </div>

          <div class="specialization-hero__info">
            <span>Formación práctica</span>
            <strong>${SPECIALIZATION.instructor}</strong>
          </div>
        </div>

        <aside class="specialization-form-card" id="specialization-form">
          <div class="specialization-form-card__header">
            <span>Solicita información</span>
            <h2>Déjanos tus datos</h2>
          </div>

          <form class="specialization-form" id="specializationLeadForm" novalidate>
            <input type="hidden" name="program" value="${SPECIALIZATION.name}" />
            <input type="hidden" name="source" value="Landing Cocina Chifa" />

            <label class="specialization-field">
              <span>Nombre completo</span>
              <input
                type="text"
                name="fullName"
                placeholder="Escribe tu nombre"
                autocomplete="name"
                required
              />
            </label>

            <label class="specialization-field">
              <span>Celular / WhatsApp</span>
              <input
                type="tel"
                name="phone"
                placeholder="Ej: 987654321"
                autocomplete="tel"
                inputmode="tel"
                required
              />
            </label>

            <label class="specialization-field">
              <span>Correo electrónico</span>
              <input
                type="email"
                name="email"
                placeholder="correo@ejemplo.com"
                autocomplete="email"
              />
            </label>

            <label class="specialization-field">
              <span>DNI</span>
              <input
                type="text"
                name="dni"
                placeholder="Ej: 12345678"
                autocomplete="off"
                inputmode="numeric"
                maxlength="12"
              />
            </label>

            <label class="specialization-field">
              <span>Mensaje</span>
              <textarea
                name="message"
                rows="3"
                placeholder="Deseo información sobre la especialización en Cocina Chifa."
              ></textarea>
            </label>

            <button class="specialization-btn specialization-btn--form" type="submit">
              Enviar solicitud
            </button>

            <p class="specialization-form__status" id="specializationFormStatus" role="status"></p>
          </form>
        </aside>
      </div>
    </section>
  `;
}

function renderLearningSection() {
  return `
    <section class="specialization-section specialization-section--white">
      <div class="container">
        <div class="specialization-heading reveal-up">
          <span class="specialization-tag">Contenido práctico</span>
          <h2>Lo que aprenderás</h2>
          <p>
            Diez temas de cocina chifa y oriental: wok, frituras, glaseados,
            salsas, masas y preparaciones tradicionales.
          </p>
        </div>

        <div class="specialization-topics-grid">
          ${renderTopicCards()}
        </div>
      </div>
    </section>
  `;
}

function renderMethodSection() {
  return `
    <section class="specialization-section specialization-section--dark">
      <div class="container specialization-method">
        <div class="specialization-method__content reveal-up">
          <span class="specialization-tag specialization-tag--light">
            Metodología
          </span>

          <h2>Aprende cocinando, paso a paso</h2>

          <p>
            Desarrolla sabores auténticos y presentaciones profesionales con
            clases prácticas, insumos incluidos y docentes capacitados.
          </p>
        </div>

        <div class="specialization-method__list">
          <article class="reveal-up">
            <strong>01</strong>
            <span>10 sesiones presenciales de 3 horas. Insumos 100% incluidos.</span>
          </article>

          <article class="reveal-up">
            <strong>02</strong>
            <span>5 al 16 de octubre · 2:00 p.m. a 5:00 p.m.</span>
          </article>

          <article class="reveal-up">
            <strong>03</strong>
            <span>Inversión: S/ 1,600.00. Certificado adicional: aprox. S/ 50.00.</span>
          </article>
        </div>
      </div>
    </section>
  `;
}

function renderAudienceSection() {
  return `
    <section class="specialization-section specialization-section--soft">
      <div class="container">
        <div class="specialization-heading reveal-up">
          <span class="specialization-tag">Perfil recomendado</span>
          <h2>¿Para quién es?</h2>
          <p>
            Dirigido al público en general, amantes de la cocina,
            chefs y personal de servicios gastronómicos.
          </p>
        </div>

        <div class="specialization-audience-grid">
          <article class="specialization-audience-card reveal-up">
            <h3>Público en general</h3>
            <p>Aprende preparaciones chifa mediante clases prácticas.</p>
          </article>

          <article class="specialization-audience-card reveal-up">
            <h3>Amantes de la cocina</h3>
            <p>Amplía tu repertorio con sabores y técnicas de cocina oriental.</p>
          </article>

          <article class="specialization-audience-card reveal-up">
            <h3>Personal gastronómico</h3>
            <p>Perfecciona el manejo del wok, glaseados y presentación de platos.</p>
          </article>
        </div>
      </div>
    </section>
  `;
}

function renderLocationCta() {
  const whatsappUrl = buildWhatsAppUrl();

  return `
    <section class="specialization-section specialization-section--cta">
      <div class="container">
        <div class="specialization-final-cta reveal-up">
          <div>
            <span class="specialization-tag">Admisión</span>
            <h2>Solicita informes</h2>
            <p>
              Inscríbete a Cocina Chifa, en modalidad presencial. Inicia el
              ${SPECIALIZATION.startDate}, tiene ${SPECIALIZATION.duration}
              y se desarrollará ${SPECIALIZATION.schedule}.
              Inversión: ${SPECIALIZATION.investment}, con insumos incluidos.
              ${SPECIALIZATION.certificate}.
            </p>
          </div>

          <div class="specialization-final-cta__actions">
            <a
              class="specialization-btn specialization-btn--primary-red"
              href="${whatsappUrl}"
              target="_blank"
              rel="noopener noreferrer"
            >
              WhatsApp
            </a>

            <a
              class="specialization-btn specialization-btn--outline"
              href="#specialization-form"
            >
              Completar formulario
            </a>
          </div>
        </div>
      </div>
    </section>
  `;
}

function getFormValue(formData: FormData, key: string) {
  return String(formData.get(key) ?? "").trim();
}

function setFormStatus(message: string, type: "success" | "error" | "info") {
  const status = document.getElementById("specializationFormStatus");
  if (!status) return;

  status.textContent = message;
  status.className = `specialization-form__status is-${type}`;
}

function isSpecializationMobile() {
  return window.matchMedia("(max-width: 820px)").matches;
}

function getSpecializationFormCard() {
  return document.getElementById("specialization-form") as HTMLElement | null;
}

function scrollToSpecializationForm() {
  const formCard = getSpecializationFormCard();
  if (!formCard) return;

  const headerOffset = isSpecializationMobile() ? 82 : 110;
  const targetPosition =
    formCard.getBoundingClientRect().top + window.scrollY - headerOffset;

  window.scrollTo({
    top: Math.max(targetPosition, 0),
    behavior: "smooth",
  });
}

function focusSpecializationFirstInput() {
  const formCard = getSpecializationFormCard();
  if (!formCard) return;

  const firstInput = formCard.querySelector<HTMLInputElement>(
    'input[name="fullName"]'
  );

  window.setTimeout(() => {
    firstInput?.focus({ preventScroll: true });
  }, 420);
}

function triggerSpecializationFormAlert() {
  const formCard = getSpecializationFormCard();
  if (!formCard) return;

  formCard.classList.remove("is-alerting");

  // Reinicia la animación aunque el usuario presione varias veces.
  void formCard.offsetWidth;

  formCard.classList.add("is-alerting");
  setFormStatus("Completa el formulario para solicitar tu inscripción.", "info");
  focusSpecializationFirstInput();

  window.setTimeout(() => {
    formCard.classList.remove("is-alerting");
  }, 1500);
}

function initSpecializationPrimaryAction() {
  const buttons = document.querySelectorAll<HTMLButtonElement>(
    "[data-specialization-primary-action]"
  );

  if (!buttons.length) return;

  buttons.forEach((button) => {
    button.addEventListener("click", (event) => {
      event.preventDefault();
      event.stopPropagation();

      if (isSpecializationMobile()) {
        scrollToSpecializationForm();

        window.setTimeout(() => {
          triggerSpecializationFormAlert();
        }, 560);

        return;
      }

      triggerSpecializationFormAlert();
    });
  });
}

function initSpecializationForm() {
  const form = document.getElementById(
    "specializationLeadForm"
  ) as HTMLFormElement | null;

  if (!form) return;

  form.addEventListener("submit", async (event) => {
    event.preventDefault();

    const submitButton = form.querySelector<HTMLButtonElement>(
      'button[type="submit"]'
    );

    const formData = new FormData(form);

    const payload: SpecializationLeadPayload = {
      program: getFormValue(formData, "program"),
      source: getFormValue(formData, "source"),
      fullName: getFormValue(formData, "fullName"),
      phone: getFormValue(formData, "phone").replace(/\D/g, ""),
      email: getFormValue(formData, "email"),
      dni: getFormValue(formData, "dni"),
      message: getFormValue(formData, "message"),
      topics: SPECIALIZATION.topics,
      instructor: SPECIALIZATION.instructor,
      pageUrl: pageLocation(),
      createdAt: new Date().toISOString(),
    };

    if (!payload.fullName || !payload.phone) {
      setFormStatus("Completa tu nombre y celular.", "error");
      return;
    }

    if (payload.phone.length < 9 || payload.phone.length > 12) {
      setFormStatus("El celular debe tener entre 9 y 12 números.", "error");
      return;
    }

    if (!isValidEmail(payload.email)) {
      setFormStatus("Ingresa un correo válido.", "error");
      return;
    }

    try {
      submitButton?.setAttribute("disabled", "true");
      if (submitButton) submitButton.textContent = "Enviando...";
      setFormStatus("Enviando solicitud...", "info");
      trackEvent("lead_submit", { form_id: "specialization", lead_method: "form", cta_location: "specialization_form" });
      await sendSpecializationLeadToSales(payload);
      trackEvent("generate_lead", { form_id: "specialization", lead_method: "form", cta_location: "specialization_form" });

      form.reset();
      setFormStatus(
        "Solicitud enviada correctamente. Te contactaremos pronto.",
        "success"
      );
    } catch (error) {
      trackEvent("lead_error", { form_id: "specialization", lead_method: "form", cta_location: "specialization_form", error_code: error instanceof LeadDeliveryError ? error.code : "unknown_error" });
      setFormStatus(
        error instanceof Error
          ? error.message
          : "Ocurrió un error. Escríbenos por WhatsApp.",
        "error"
      );
    } finally {
      submitButton?.removeAttribute("disabled");
      if (submitButton) submitButton.textContent = "Enviar solicitud";
    }
  });
}

function initRevealEffects() {
  const elements = document.querySelectorAll<HTMLElement>(".reveal-up");

  if (!elements.length) return;

  const observer = new IntersectionObserver(
    (entries) => {
      entries.forEach((entry) => {
        if (!entry.isIntersecting) return;

        entry.target.classList.add("is-visible");
        observer.unobserve(entry.target);
      });
    },
    {
      threshold: 0.16,
      rootMargin: "0px 0px -40px 0px",
    }
  );

  elements.forEach((element) => observer.observe(element));
}

export function renderSpecializationPage() {
  return `
    <div class="site-shell specialization-page">
      ${renderHeader()}

      <main>
        ${renderSpecializationHero()}
        ${renderLearningSection()}
        ${renderMethodSection()}
        ${renderAudienceSection()}
        ${renderLocationCta()}
      </main>

      ${renderFooter()}
    </div>
  `;
}

export function initSpecializationPage() {
  initHeader();
  initSpecializationForm();
  initSpecializationPrimaryAction();
  initRevealEffects();
  initSpecializationSwirlBackground();
}
